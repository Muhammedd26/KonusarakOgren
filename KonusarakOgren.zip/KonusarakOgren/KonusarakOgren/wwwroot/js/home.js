﻿
function frmAjaxSuccess(response) {
    loadingEnd();
    console.log(response);
    toastMessage(response.statusCode, response.message);
    if (response.statusCode == "success") {
        $("#hiddenSubject_" + response.target).css("display","none");
    }
}

function CreateQuestion(target, url,title) {
    if ($("#hiddenSubject_" + target).css("display") == "none") {
        loadingBegin();
        $("#hiddenSubject_" + target).fadeIn();
        $("#i_" + target).removeClass("fa-chevron-down");
        $("#i_" + target).addClass("fa-chevron-up");
        $.ajax({
            url: "/Home/GetCreateQuestion",
            type: "post",
            dataType: "html",
            data: { url, title, target },
            success: function (html) {
                $("#hiddenSubject_" + target).html(html);
                loadingEnd();
            }
        });
    } else {
        $("#hiddenSubject_" + target).fadeOut();
        $("#hiddenSubject_" + target).html("");
        $("#i_" + target).addClass("fa-chevron-down");
        $("#i_" + target).removeClass("fa-chevron-up");
    }

}

