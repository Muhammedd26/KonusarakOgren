﻿function setQuestionAnswer(answer, target) {
    $("#Answer_" + target).val(answer);
}

function frmExamSuccess(response) {
    console.log(response);
    $.each(response, function (key, value) {
        $(".answer-" + value.questionId + "-" + value.userAnswerId).css("background-color", "red")
        $(".answer-" + value.questionId + "-" + value.answerId).css("background-color", "green")
    });
    $("#btnEndExam").remove();
    $("#btnGoBack").css("display","");
}