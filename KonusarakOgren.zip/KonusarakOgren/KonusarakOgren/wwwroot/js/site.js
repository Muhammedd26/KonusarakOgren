﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
function frmAjaxBegin(event) {
    loadingBegin();
}
function jsFormError(response) {
    try {
        var responseJSON = response.responseJSON;
        toastMessage(responseJSON.statusCode, responseJSON.message, "");
    } catch (e) {
        toastMessage("error", "Sonuç Değeri Okunamadı", "");
    }


}

function toastMessage(type, message, possition) {

    toasting.create({
        "title" : "İşlem Sonucu",
        "text": message,
        "type": type,
        "progressBarType": type

    });
    
}

function loadingBegin() {
    document.getElementById("loader").style.display = "";
}
function startPage() {
    setTimeout(loadingEnd, 1000);
}

function loadingEnd() {
    document.getElementById("loader").style.display = "none";
    document.getElementById("container").style.display = "block";
}