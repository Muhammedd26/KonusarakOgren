﻿using HtmlAgilityPack;
using KonusarakOgren.Helpers;
using KonusarakOgren.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace KonusarakOgren.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        SessionModel sessionModel;
        public HomeController(ILogger<HomeController> logger, IHttpContextAccessor _httpContextAccessor)
        {
            _logger = logger;
            GetSession getSession = new GetSession(_httpContextAccessor);
            sessionModel = getSession.GetSessionModel();
        }

        public IActionResult Index()
        {
            if (sessionModel == null) return RedirectToAction("Index", "Login");
            if (sessionModel.Type != 1) {
                return RedirectToAction("Index", "Exam");
            }
            ViewBag.Type = 1;
            var top5List = GetWiredTop5();
            return View(top5List);
        }
        public IActionResult ExamList()
        {
            if (sessionModel == null) return RedirectToAction("Index", "Login");
            if (sessionModel.Type != 1) {
                return RedirectToAction("Index", "Exam");
            }
            ViewBag.Type = 1;
            using (CONTEXT context = new CONTEXT())
            {
                var exmas = context.EXAMS.ToList();
                return View(exmas);

            }

        }
        [HttpPost]
        public IActionResult DeleteExam(int id)
        {
            try
            {
                if (sessionModel == null) return RedirectToAction("Index", "Login");
                if (sessionModel.Type != 1)
                {
                    return RedirectToAction("Index", "Exam");
                }
                ViewBag.Type = 1;
                using (CONTEXT context = new CONTEXT())
                {
                    var exmas = context.EXAMS.Where(x => x.ID == id).FirstOrDefault();

                    var userExams = context.USEREXAMS.Where(x => x.EXAMID == id).ToList();
                    foreach (var item in userExams)
                    {
                        var userAnswers = context.USERANSWER.Where(x => x.USEREXAMID == item.ID).ToList();
                        if (userAnswers.Count() > 0)
                        {
                            context.USERANSWER.RemoveRange(userAnswers);
                            context.SaveChanges();
                        }
                    }
                    if (userExams.Count() > 0)
                    {
                        context.RemoveRange(userExams);
                        context.SaveChanges();
                    }


                    var questions = context.QUESTIONS.Where(x => x.EXAMID == id).ToList();
                    foreach (var item in questions)
                    {
                        var answers = context.QUESTIONOPTIONS.Where(x => x.QUESTIONID == item.ID).ToList();
                        context.QUESTIONOPTIONS.RemoveRange(answers);
                        context.SaveChanges();
                    }
                    context.QUESTIONS.RemoveRange(questions);
                    context.SaveChanges();
                    context.EXAMS.Remove(exmas);
                    context.SaveChanges();
                    ResponseModel responseModel = new ResponseModel
                    {
                        StatusCode = "success",
                        Message = "Sınav Başarılı Bir Şekilde Silindi",
                        Target = id.ToString()
                    };
                    return Ok(responseModel);

                }
            }
            catch (Exception)
            {
                ResponseModel responseModel = new ResponseModel
                {
                    StatusCode = "error",
                    Message = "Sınav Silme Gerçekleştirilemedi"
                };
                return Ok(responseModel);
            }
            

        }
        public IActionResult Privacy()
        {
            if (sessionModel == null) return RedirectToAction("Index", "Login");
            if (sessionModel.Type != 1)
            {
                return RedirectToAction("Index", "Exam");
            }
            ViewBag.Type = 1;

            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            ViewBag.Type = 1;

            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpPost]
        public IActionResult CreateExam(CreateExamModel model)
        {
            if (sessionModel == null) return RedirectToAction("Index", "Login");
            if (sessionModel.Type != 1)
            {
                return RedirectToAction("Index", "Exam");
            }
            ViewBag.Type = 1;

            using (CONTEXT context = new CONTEXT())
            {
                try
                {
                    EXAM eXAM = new EXAM
                    {
                        SUBJECTTEXT = model.SubjectText,
                        SUBJECTTITLE = model.SubjectTitle,
                        WIREDURL = model.WiredUrl,
                        USERID = sessionModel.UserId
                    };
                    context.EXAMS.Add(eXAM);
                    context.SaveChanges();

                    foreach (var item in model.Soru)
                    {
                        QUESTION question = new QUESTION
                        {
                            QUESTIONTEXT = item.QuestionText,
                            EXAMID = eXAM.ID,

                        };
                        context.QUESTIONS.Add(question);
                        context.SaveChanges();
                        foreach (var option in item.Secenek)
                        {
                            QUESTIONOPTION qOption = new QUESTIONOPTION
                            {
                                QUESTIONID = question.ID,
                                OPTIONTEXT = option.Text,
                                OPTIONTYPE = option.Type
                            };
                            context.QUESTIONOPTIONS.Add(qOption);
                            context.SaveChanges();
                            if (option.Type == item.DogruCevap)
                            {
                                question.ANSWERID = qOption.ID;
                                context.QUESTIONS.Update(question);
                                context.SaveChanges();
                            }
                        }
                    }
                    ResponseModel responseModel = new ResponseModel
                    {
                        Message = "Sınav Başarıyla Oluştu",
                        StatusCode = "success",
                        Target = model.Target
                    };
                    return Ok(responseModel);

                }
                catch (Exception)
                {
                    ResponseModel responseModel = new ResponseModel
                    {
                        Message = "Sınav Oluşturulurken Hata Oluştu",
                        StatusCode = "error",
                        Target =model.Target
                    };
                    return Ok(responseModel);
                    
                }
              
            }
                

        }
        [HttpPost]
        public IActionResult GetCreateQuestion(string url,string title,string target)
        {
            if (sessionModel == null) return Unauthorized();
            if (sessionModel.Type != 1)
            {
                return Unauthorized();
            }
            ViewBag.Type = 1;

            WebClient client = new WebClient();
            client.Headers.Add("Accept: text/html, application/xhtml+xml, */*");
            client.Headers.Add("User-Agent: Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)");
            client.Encoding = Encoding.UTF8;
            string raw = client.DownloadString(url);
            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(raw);

            HtmlNodeCollection subjectText = doc.DocumentNode.SelectNodes("//div[@class='body__inner-container']");
            string body = "";
            if (subjectText != null)
            {
                foreach (var item in subjectText)
                {
                    foreach (var paragrph in item.SelectNodes("p"))
                    {
                        body += "<p>" + paragrph.InnerHtml + "</p>";

                    }
                }
            }
            else
            {
                subjectText = doc.DocumentNode.SelectNodes("//article");
                foreach (var item in subjectText)
                {
                    foreach (var paragrph in item.SelectNodes("p"))
                    {
                        body += "<p>" + paragrph.InnerHtml + "</p>";

                    }
                }
            }


            CreateQuestionModel createQuestionModel = new CreateQuestionModel
            {
                SubjectText = body,
                SubjectTitle = title,
                WiredUrl = url,
                Target = target
            };
            return PartialView("_CreateExam", createQuestionModel);
        }
        private List<Titles> GetWiredTop5()
        {
            string url = "https://www.wired.com";
            WebClient client = new WebClient();
            client.Headers.Add("Accept: text/html, application/xhtml+xml, */*");
            client.Headers.Add("User-Agent: Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)");
            client.Encoding = Encoding.UTF8;
            string raw = client.DownloadString(url);
            HtmlAgilityPack.HtmlDocument doc = new HtmlAgilityPack.HtmlDocument();
            doc.LoadHtml(raw);
            List<Titles> titleList = new List<Titles>();
            HtmlNodeCollection titles = doc.DocumentNode.SelectNodes("//li[@class='card-component__description card-component__description--standard']");
            if (titles != null)
            {
                var titleA = titles[0].SelectNodes("a")[1];
                Titles titles1 = new Titles
                {
                    Title = titleA.InnerText,
                    Url = url + titleA.Attributes["href"].Value
                };
                titleList.Add(titles1);
            }
            HtmlNodeCollection titlesnarrow = doc.DocumentNode.SelectNodes("//li[@class='card-component__description card-component__description--narrow']");
            if (titlesnarrow != null)
            {
                var titleA = titlesnarrow[0].SelectNodes("a")[1];
                Titles titles1 = new Titles
                {
                    Title = titleA.InnerText,
                    Url = url + titleA.Attributes["href"].Value
                };
                titleList.Add(titles1);
            }
            HtmlNodeCollection titlesSmall = doc.DocumentNode.SelectNodes("//li[@class='card-component__description card-component__description--small']");
            if (titlesSmall != null)
            {
                var titleA = titlesSmall[0].SelectNodes("a")[1];
                Titles titles1 = new Titles
                {
                    Title = titleA.InnerText,
                    Url = url + titleA.Attributes["href"].Value
                };
                titleList.Add(titles1);
            }
            HtmlNodeCollection titlesText = doc.DocumentNode.SelectNodes("//li[@class='card-component__description card-component__description--text']");
            if (titlesText != null)
            {
                var titleA = titlesText[0].SelectNodes("a")[1];
                Titles titles1 = new Titles
                {
                    Title = titleA.InnerText,
                    Url = url + titleA.Attributes["href"].Value
                };
                titleList.Add(titles1);
            }
            HtmlNodeCollection titlesSmallReserved = doc.DocumentNode.SelectNodes("//li[@class='card-component__description card-component__description--small-reversed']");
            if (titlesSmallReserved != null)
            {
                var titleA = titlesSmallReserved[0].SelectNodes("a")[1];
                Titles titles1 = new Titles
                {
                    Title = titleA.InnerText,
                    Url = url + titleA.Attributes["href"].Value
                };
                titleList.Add(titles1);
            }

            return titleList;
        }

    }
}
