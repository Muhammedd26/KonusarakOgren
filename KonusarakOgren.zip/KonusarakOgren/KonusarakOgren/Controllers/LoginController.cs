﻿using KonusarakOgren.Helpers;
using KonusarakOgren.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Controllers
{
    public class LoginController : Controller
    {
        SessionModel sessionModel;
        public LoginController(IHttpContextAccessor _httpContextAccessor)
        {
            GetSession getSession = new GetSession(_httpContextAccessor);
            sessionModel = getSession.GetSessionModel();
        }
        public IActionResult Index()
        {
            if (sessionModel != null) return RedirectToAction("Index", "Home");

            return View();
        }

        [HttpPost]
        public IActionResult Index(string UserName,string Password)
        {
            if (String.IsNullOrEmpty(UserName))
            {
                ResponseModel responseModel = new ResponseModel
                {
                    Message = "Kullanıcı Adı Alanını Boş Geçemezsiniz",
                    StatusCode = "error"
                };
                return View("Index", responseModel);
            }
            if (String.IsNullOrEmpty(Password))
            {
                ViewBag.UserName = UserName;
                ResponseModel responseModel = new ResponseModel
                {
                    Message = "Şifre Alanını Boş Geçemezsiniz",
                    StatusCode = "error"
                };
                return View("Index", responseModel);
            }
            string localPath = Path.GetFullPath("DBFILE/");
            string dbPath = localPath + "KONUSARAKOGREN.db";
            CONTEXT context = new CONTEXT();
            if (!System.IO.File.Exists(dbPath))
            {
                context.Database.Migrate();
                USER adminUser = new USER
                {
                    PASSWORD = "admin123",
                    USERNAME = "admin",
                    TYPE = 1
                };
                context.USERS.Add(adminUser);
                context.SaveChanges();
                USER firstUser = new USER
                {
                    PASSWORD = "user123",
                    USERNAME = "user",
                    TYPE = 2
                };
                context.USERS.Add(firstUser);
                context.SaveChanges();
            }
           
            USER user = context.USERS.Where(x=>x.USERNAME.Equals(UserName) && x.PASSWORD.Equals(Password)).FirstOrDefault();
            if (user != null)
            {
                SessionModel sessionModel = new SessionModel
                {
                    UserId = user.ID,
                    Username = user.USERNAME,
                    Type = user.TYPE,
                    SystemEnteredTime = DateTime.Now.AddHours(3)
                };
                string sessionJson = JsonConvert.SerializeObject(sessionModel).ToString();
                sessionJson = Project_Encyrption.Encode(sessionJson);

                HttpContext.Session.SetString("KO_Session", sessionJson);
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.UserName = UserName;

                ResponseModel responseModel = new ResponseModel
                {
                    Message = "Kullanıcı Bulunamadı",
                    StatusCode = "error"
                };
                return View("Index",responseModel);
            }
        }
        [HttpGet]
        public IActionResult Logout()
        {
            // await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme); 
            HttpContext.Session.Remove("KO_Session");

            return RedirectToAction("Index", "Login");
        }
    }
}
