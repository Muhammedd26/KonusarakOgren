﻿using KonusarakOgren.Helpers;
using KonusarakOgren.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Controllers
{
    public class ExamController : Controller
    {
        SessionModel sessionModel;
        public ExamController(IHttpContextAccessor _httpContextAccessor)
        {
            GetSession getSession = new GetSession(_httpContextAccessor);
            sessionModel = getSession.GetSessionModel();
        }

        public IActionResult Index()
        {
            if (sessionModel == null) return RedirectToAction("Index", "Login");
            if (sessionModel.Type != 2)
            {
                return RedirectToAction("Index", "Home");
            }
            using (CONTEXT context = new CONTEXT())
            {
                var exams = context.EXAMS.ToList();
                return View(exams);

            }
        }
        public IActionResult GetExamStatus(int id)
        {
            if (sessionModel == null) return Unauthorized();
            if (sessionModel.Type != 2)
            {
                return Unauthorized();
            }

            using (CONTEXT context = new CONTEXT())
            {
                var userExams = context.USEREXAMS.Where(x => x.USERID == sessionModel.UserId && x.EXAMID == id).FirstOrDefault();
                if (userExams == null)
                {
                    return Ok(new { result = "<a href=\"/Exam/JoinExam/"+id+"\">Sınava Katıl</a>" });
                }
                int dogrular = 0;
                int yanlislar = 0;

                var exams = context.EXAMS.Where(x => x.ID == id).Include(x => x.QUESTIONS).FirstOrDefault();
                var userAnswer = context.USERANSWER.Where(x => x.USEREXAMID == userExams.ID).ToList();
                foreach (var item in userAnswer)
                {
                    var isTrue = context.QUESTIONS.Where(x => x.ID == item.QUESTIONID && x.ANSWERID == item.ANSWERID).FirstOrDefault();
                    if (isTrue == null)
                    {
                        yanlislar++;
                    }
                    else
                    {
                        dogrular++;
                    }
                }
                return Ok(new { result = "(" + dogrular + " / 4" + ")" });

            }

        }
        public IActionResult JoinExam(int id)
        {
            if (sessionModel == null) return RedirectToAction("Index", "Login");
            if (sessionModel.Type != 2)
            {
                return RedirectToAction("Index", "Home");
            }


            using (CONTEXT context = new CONTEXT())
            {
                var userExams = context.USEREXAMS.Where(x => x.USERID == sessionModel.UserId && x.EXAMID == id).FirstOrDefault();
                if (userExams != null)
                {
                    return View("Error");
                }
                var exams = context.EXAMS.Where(x => x.ID == id).Include(x => x.QUESTIONS).FirstOrDefault();
                foreach (var item in exams.QUESTIONS)
                {
                    item.QUESTIONOPTIONS = context.QUESTIONOPTIONS.Where(x => x.QUESTIONID == item.ID).ToList();
                }
                return View(exams);

            }

        }
        [HttpPost]
        public IActionResult JoinExam(USEREXAM model)
        {
            if (sessionModel == null) return RedirectToAction("Index", "Login");
            if (sessionModel.Type != 2)
            {
                return RedirectToAction("Index", "Home");
            }

            using (CONTEXT context = new CONTEXT())
            {
                var examAnswers = context.QUESTIONS.Where(x => x.EXAMID == model.EXAMID).ToList();
                USEREXAM userExam = new USEREXAM
                {
                    EXAMID = model.EXAMID,
                    USERID = sessionModel.UserId
                };
                context.USEREXAMS.Add(userExam);
                context.SaveChanges();
                List<object> response = new List<object>();
                foreach (var item in model.USERANSWERS)
                {
                    item.USEREXAMID = userExam.ID;
                    context.USERANSWER.Add(item);
                    context.SaveChanges();
                    var questionResult = examAnswers.Where(x => x.ID == item.QUESTIONID).FirstOrDefault();
                    response.Add(new
                    {
                        questionId = item.QUESTIONID,
                        answerId = questionResult.ANSWERID,
                        userAnswerId = item.ANSWERID
                    });
                }

                return Ok(response);
            }
        }
    }
}
