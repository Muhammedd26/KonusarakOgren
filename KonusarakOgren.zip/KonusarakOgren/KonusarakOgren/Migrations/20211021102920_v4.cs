﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace KonusarakOgren.Migrations
{
    public partial class v4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_QUESTIONS_EXAMID",
                table: "QUESTIONS",
                column: "EXAMID");

            migrationBuilder.CreateIndex(
                name: "IX_QUESTIONOPTIONS_QUESTIONID",
                table: "QUESTIONOPTIONS",
                column: "QUESTIONID");

            migrationBuilder.AddForeignKey(
                name: "FK_QUESTIONOPTIONS_QUESTIONS_QUESTIONID",
                table: "QUESTIONOPTIONS",
                column: "QUESTIONID",
                principalTable: "QUESTIONS",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_QUESTIONS_EXAMS_EXAMID",
                table: "QUESTIONS",
                column: "EXAMID",
                principalTable: "EXAMS",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_QUESTIONOPTIONS_QUESTIONS_QUESTIONID",
                table: "QUESTIONOPTIONS");

            migrationBuilder.DropForeignKey(
                name: "FK_QUESTIONS_EXAMS_EXAMID",
                table: "QUESTIONS");

            migrationBuilder.DropIndex(
                name: "IX_QUESTIONS_EXAMID",
                table: "QUESTIONS");

            migrationBuilder.DropIndex(
                name: "IX_QUESTIONOPTIONS_QUESTIONID",
                table: "QUESTIONOPTIONS");
        }
    }
}
