﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace KonusarakOgren.Migrations
{
    public partial class version_1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "EXAMS",
                columns: table => new
                {
                    ID = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    SUBJECTTITLE = table.Column<string>(type: "TEXT", maxLength: 250, nullable: true),
                    SUBJECTTEXT = table.Column<string>(type: "TEXT", nullable: true),
                    CREATEDDATE = table.Column<DateTime>(type: "TEXT", nullable: false),
                    USERID = table.Column<int>(type: "INTEGER", nullable: false),
                    WIREDURL = table.Column<string>(type: "TEXT", maxLength: 250, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EXAMS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "QUESTIONOPTIONS",
                columns: table => new
                {
                    ID = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    QUESTIONID = table.Column<int>(type: "INTEGER", nullable: false),
                    OPTIONTEXT = table.Column<string>(type: "TEXT", nullable: true),
                    OPTIONTYPE = table.Column<string>(type: "TEXT", maxLength: 10, nullable: true),
                    CREATEDDATE = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QUESTIONOPTIONS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "QUESTIONS",
                columns: table => new
                {
                    ID = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    QUESTIONTEXT = table.Column<string>(type: "TEXT", nullable: true),
                    EXAMID = table.Column<int>(type: "INTEGER", nullable: false),
                    ANSWERID = table.Column<int>(type: "INTEGER", nullable: false),
                    CREATEDDATE = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QUESTIONS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "USERANSWER",
                columns: table => new
                {
                    ID = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    USEREXAMID = table.Column<int>(type: "INTEGER", nullable: false),
                    ANSWERID = table.Column<int>(type: "INTEGER", nullable: false),
                    QUESTIONID = table.Column<int>(type: "INTEGER", nullable: false),
                    CREATEDDATE = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_USERANSWER", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "USEREXAMS",
                columns: table => new
                {
                    ID = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    USERID = table.Column<int>(type: "INTEGER", nullable: false),
                    EXAMID = table.Column<int>(type: "INTEGER", nullable: false),
                    CREATEDDATE = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_USEREXAMS", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "USERS",
                columns: table => new
                {
                    ID = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    USERNAME = table.Column<string>(type: "TEXT", maxLength: 50, nullable: true),
                    PASSWORD = table.Column<string>(type: "TEXT", maxLength: 50, nullable: true),
                    TYPE = table.Column<int>(type: "INTEGER", nullable: false),
                    CREATEDDATE = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_USERS", x => x.ID);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EXAMS");

            migrationBuilder.DropTable(
                name: "QUESTIONOPTIONS");

            migrationBuilder.DropTable(
                name: "QUESTIONS");

            migrationBuilder.DropTable(
                name: "USERANSWER");

            migrationBuilder.DropTable(
                name: "USEREXAMS");

            migrationBuilder.DropTable(
                name: "USERS");
        }
    }
}
