﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonusarakOgren.Helpers
{
    public class HashFile
    {
        public string Hash = "KonusarakOgren";
    }
}
