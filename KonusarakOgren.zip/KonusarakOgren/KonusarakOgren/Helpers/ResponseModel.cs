﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Helpers
{
    public class ResponseModel
    {
        public string StatusCode { get; set; }
        public string Message { get; set; }
        public string Target { get; set; }
    }
}
