﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Helpers
{
    public class CreateQuestionModel
    {
        public string SubjectTitle { get; set; }
        public string SubjectText { get; set; }
        public string WiredUrl { get; set; }
        public string Target { get; set; }
    }
}
