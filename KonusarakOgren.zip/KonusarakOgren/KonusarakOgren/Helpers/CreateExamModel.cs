﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Helpers
{
    public class CreateExamModel
    {
        public string SubjectText { get; set; }
        public string SubjectTitle { get; set; }
        public string WiredUrl { get; set; }
        public string Target { get; set; }
        public List<Question> Soru { get; set; }
    }
    public class Question
    {
        public string QuestionText { get; set; }
        public List<OuestionOptions> Secenek { get; set; }
        public string DogruCevap { get; set; }
    }

    public class OuestionOptions
    {
        public string Text { get; set; }
        public string Type { get; set; }
    }
}
