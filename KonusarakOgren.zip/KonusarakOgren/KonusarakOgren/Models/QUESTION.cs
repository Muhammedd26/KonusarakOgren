﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Models
{
    public class QUESTION
    {
        [Key]
        public int ID { get; set; }
        public string QUESTIONTEXT { get; set; }
        public int EXAMID { get; set; }
        public virtual EXAM EXAM{get;set;}
        public int ANSWERID { get; set; }
        public DateTime CREATEDDATE { get; set; } = DateTime.Now;
        public virtual ICollection<QUESTIONOPTION> QUESTIONOPTIONS { get; set; }
    }
}
