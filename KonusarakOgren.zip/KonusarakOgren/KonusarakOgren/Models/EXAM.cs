﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Models
{
    public class EXAM
    {
        [Key]
        public int ID { get; set; }
        [MaxLength(250)]
        public string SUBJECTTITLE { get; set; }
        public string SUBJECTTEXT { get; set; }
        public DateTime CREATEDDATE { get; set; } = DateTime.Now;
        public int USERID { get; set; }
        [MaxLength(250)]
        public string WIREDURL { get; set; }

        public virtual ICollection<QUESTION> QUESTIONS { get; set; }
    }
}
