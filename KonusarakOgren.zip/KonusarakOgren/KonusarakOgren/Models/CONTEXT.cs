﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Models
{
    public class CONTEXT : DbContext
    {
        public DbSet<USER> USERS { get; set; }
        public DbSet<EXAM> EXAMS { get; set; }
        public DbSet<QUESTION> QUESTIONS { get; set; }
        public DbSet<QUESTIONOPTION> QUESTIONOPTIONS { get; set; }
        public DbSet<USERANSWER> USERANSWER { get; set; }
        public DbSet<USEREXAM> USEREXAMS { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string localPath = Path.GetFullPath("DBFILE/");
            string dbPath = localPath + "KONUSARAKOGREN.db";

            optionsBuilder.UseSqlite(@"Data Source=" + dbPath);

        }
    }
}
