﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Models
{
    public class USER
    {
        [Key]
        public int ID { get; set; }
        [MaxLength(50)]
        public string USERNAME { get; set; }
        [MaxLength(50)]
        public string PASSWORD { get; set; }
        public int TYPE { get; set; }
        public DateTime CREATEDDATE { get; set; } = DateTime.Now;
    }
}
