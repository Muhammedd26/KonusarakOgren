﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Models
{
    public class QUESTIONOPTION
    {
        [Key]
        public int ID { get; set; }
        public int QUESTIONID { get; set; }
        public virtual QUESTION QUESTION { get; set; }
        public string OPTIONTEXT { get; set; }
        [MaxLength(10)]
        public string OPTIONTYPE { get; set; }
        public DateTime CREATEDDATE { get; set; } = DateTime.Now;
    }
}
