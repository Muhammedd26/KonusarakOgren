﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Models
{
    public class USEREXAM
    {
        [Key]
        public int ID { get; set; }
        public int USERID { get; set; }
        public int EXAMID { get; set; }
        public DateTime CREATEDDATE { get; set; } = DateTime.Now;

        public virtual ICollection<USERANSWER> USERANSWERS { get; set; }
    }
}
