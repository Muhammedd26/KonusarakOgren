﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace KonusarakOgren.Models
{
    public class USERANSWER
    {
        [Key]
        public int ID { get; set; }
        public int USEREXAMID { get; set; }
        public int ANSWERID { get; set; }
        public int QUESTIONID { get; set; }
        public DateTime CREATEDDATE { get; set; } = DateTime.Now;
    }
}
